# 10 · Shopify CLI, Local Development, and Git

🟡 Intermediate

Verification: ✅ = checked against shopify.dev CLI reference on 2026-10-06 (`theme dev` page and CLI theme command index). ⚠️ = flag details not checked on the official reference this session; run `shopify theme <command> --help` to confirm on your installed version.

## What this is

How to develop themes locally against a real store using Shopify CLI, and how to wrap that in Git so changes are reviewed, tested, and reversible.

## Why it matters

The theme editor's code editor has no real history, review, or tests. Professional work needs version control, a safe preview, and a repeatable deploy.

## Mental model

```mermaid
flowchart LR
    G[(Git repo)] --> L[Local files]
    L -->|shopify theme dev| D[Development theme on dev store]
    L -->|shopify theme push| U[Unpublished theme: staging]
    U -->|review + QA| P[Publish]
    P --> Live[Live theme]
    Live -->|shopify theme pull| L
```

**Source of truth for code = Git. Source of truth for merchant content/settings = the store.** Keeping those two separate prevents most deployment accidents.

## Shopify concept: CLI versions ✅

- **Shopify CLI 3.x+** is current.
- **Shopify CLI 2.x is deprecated and no longer supported** ✅. 🏛️ Old tutorials using `shopify theme serve` and `shopify theme init` from 2.x flows are historical. Use the 3.x commands.

## Development store

A **development store** is a free store for building and testing ✅. Created from the **Dev Dashboard** ✅ (select Dev Stores → Create store; optionally generate test data).

Facts ✅:

- Always password protected.
- Unlimited test orders, unlimited products, up to 10 custom apps.
- You can only install free apps and Partner-friendly apps.
- Certain features (developer previews, custom/draft apps) prevent transferring the store to a client.

## Install and authenticate

```bash
npm install -g @shopify/cli    # ⚠️ confirm package name on the CLI install page
shopify version
shopify theme list --store=your-dev-store.myshopify.com
```

- **What it does:** installs the CLI; `theme list` triggers login in the browser if needed.
- **What it changes:** nothing in your store; stores a login session locally.
- **Common failure:** Node version too old; permission errors on global install.
- **Recovery:** use a Node version manager; check CLI requirements on shopify.dev.

## Command reference ✅ (names) / ⚠️ (flags where marked)

The CLI theme command set includes: `theme check`, `console`, `delete`, `dev`, `info`, `init`, `language-server`, `list`, `metafields pull`, `open`, `package`, `profile`, `publish`, `pull`, `push`, `rename`, `share` ✅.

### `shopify theme dev` ✅

```bash
shopify theme dev --store=your-dev-store.myshopify.com
```

- **What it does:** uploads the current local theme as a **development theme** (or as a specified theme) and serves a local preview at `http://127.0.0.1:9292` ✅. It also prints a theme-editor link and a shareable preview link ✅.
- **What it changes:** creates/replaces a *development theme* on the store. If you already have one for this environment, it **replaces** it with your local theme ✅. Override with `--theme-editor-sync` ✅.
- **Live reload ✅:** `--live-reload hot-reload` (default, CSS and sections), `full-page`, or `off`.
- **Useful flags ✅:** `--port`, `--host`, `--open`, `--theme <id|name>`, `--only <pattern>`, `--ignore <pattern>`, `--nodelete`, `--environment <name>`, `--allow-live` (develop on a live theme; dangerous), `--store-password` (for password-protected storefronts), `--password` (Theme Access token).
- **Constraints ✅:** must be run in a directory matching the standard theme structure; **you can't preview checkout customizations at 127.0.0.1:9292**.
- **Lifecycle ✅:** development themes are **deleted** when you run `shopify auth logout`. If you need a link that survives logout, use `theme share` or push to an unpublished theme.
- **When to use:** all day-to-day work.
- **Common failure:** "not a theme directory" (wrong folder), port in use (use `--port`), editor-side changes diverging from local files.
- **Recovery:** run from the theme root; choose another port; use `--theme-editor-sync` deliberately when merchants/designers edit in the editor, and pick a `--reconciliation-strategy` (`keep-local`, `keep-remote`, `abort`) ✅.

### `shopify theme pull`

```bash
shopify theme pull --store=your-dev-store.myshopify.com --theme=<id-or-name>
shopify theme pull --only 'templates/*.json' --only 'config/settings_data.json'
```

- **What it does:** downloads remote theme files into the local folder.
- **What it changes:** **local files**, possibly deleting local files that don't exist remotely ⚠️ (use `--nodelete` ✅ on `dev`; check `pull --help` for the equivalent).
- **When to use:** start of a project; to capture merchant/editor changes to JSON templates and settings before they are lost.
- **Common failure:** pulling over uncommitted local work.
- **Recovery:** commit or stash first; `git restore`/`git checkout` to recover.

### `shopify theme push`

```bash
shopify theme push --unpublished --theme "Staging 2026-10-06"   # ⚠️ confirm flags with --help
shopify theme push --theme=<id> --ignore 'config/settings_data.json' --ignore 'templates/*.json'
```

- **What it does:** uploads local theme files to a remote theme.
- **What it changes:** the **remote theme's files**. Pushing to the live theme changes the live store immediately.
- **Safety:** push to an **unpublished** theme for staging. Use `--ignore` for files that merchants edit (for example `config/settings_data.json`, and often JSON templates) ✅ (flag names mirror `theme dev`).
- **Common failure:** overwriting merchant settings; pushing to the wrong theme ID.
- **Recovery:** if you have the previous version in Git or a duplicate theme, restore from there. Duplicate the live theme in admin *before* any risky push.

### `shopify theme check`

```bash
shopify theme check
```

- **What it does:** runs Theme Check (static analysis for Liquid, schema, performance, and structure) ✅ (command exists).
- **What it changes:** nothing unless you pass an auto-correct option ⚠️.
- **When to use:** before every commit and in CI.
- **Common failure:** noisy results on third-party code. Configure `.theme-check.yml` ⚠️.

### `shopify theme publish`, `share`, `list`, `open`, `delete`, `rename`, `package` ✅ (names)

| Command | Use |
|---|---|
| `list` | See themes and IDs on the store |
| `share` | Create a shareable preview link for a theme |
| `publish` | Make a theme live (confirm carefully) |
| `open` | Open the theme/editor/preview URL |
| `rename` / `delete` | Housekeeping. **Delete is irreversible** |
| `package` | Zip theme files (⚠️ confirm output details) |
| `metafields pull` | Pull metafield definitions to local files (for editor/tooling support) ⚠️ |
| `console` | Interactive Liquid REPL against store data ⚠️ |

## Recommended repository layout

```text
repo/
├── .gitignore
├── .theme-check.yml
├── shopify.theme.toml        # ⚠️ environments config: confirm file name and fields in CLI docs
├── README.md
└── theme/                    # or repo root, if the repo *is* the theme
    ├── assets/ blocks/ config/ layout/ locales/ sections/ snippets/ templates/
```

📘 Add a `README` documenting store URLs, theme IDs, and deploy steps. Never commit tokens or passwords; use environment variables (for example `SHOPIFY_CLI_THEME_TOKEN` is the documented env var for `--password` ✅).

## Environments

| Environment | Store | Theme | Purpose |
|---|---|---|---|
| Local | dev store | development theme (`theme dev`) | Individual work |
| Preview | dev/staging store | unpublished theme | PR review and QA |
| Production | client store | live theme | Customers |

Use the CLI's `--environment` flag ✅ with a config file to select these. ⚠️ Confirm the config format in current docs.

## Git workflow 📘 Engineering

```mermaid
gitGraph
    commit id: "main = live"
    branch feature/cart-drawer
    commit id: "cart drawer"
    commit id: "a11y fixes"
    checkout main
    merge feature/cart-drawer tag: "release"
```

**Solo developer**

1. `git switch -c feature/<short-name>`
2. `shopify theme dev` against a dev store.
3. `shopify theme check`; commit small, descriptive messages.
4. Push to an unpublished theme; test on real devices.
5. Merge to `main`, duplicate live theme (backup), push to production or publish the tested theme.

**Team**

1. Branch per feature; pull request required.
2. CI runs `shopify theme check` (and tests when present).
3. Reviewer checks: schema changes, settings IDs, a11y, performance impact.
4. Each PR gets a preview theme; QA signs off.
5. A release owner deploys; the previous live theme is kept as rollback.

**Branch naming:** `feature/…`, `fix/…`, `chore/…`, `release/YYYY-MM-DD`.
**Commit style:** imperative, scoped: `cart: add loading state to remove button`.

### Settings and template conflicts 📘

Merchants edit `config/settings_data.json` and `templates/*.json` in the theme editor. Options:

- **A.** Treat those files as store-owned: exclude them from push with `--ignore`; pull them occasionally for reference.
- **B.** Treat them as code-owned and require merchants to stop editing during a release window.
- **C.** Use `--theme-editor-sync` ✅ during development to sync editor changes into local files, with an explicit `--reconciliation-strategy`.

Pick one policy per project and document it in the README.

## Rollback strategy 📘

1. Before release: duplicate the live theme in admin ("Backup before release-YYYY-MM-DD").
2. If the release fails: publish the backup theme (instant revert for theme code).
3. Then fix forward in Git.

Limits: rollback restores *theme files*. It does not undo app changes, metafield definitions, or data changes.

## Common mistakes

- Developing against the live theme (`--allow-live`).
- Pushing `settings_data.json` over merchant changes.
- Using Shopify CLI 2.x commands from old tutorials 🏛️.
- Forgetting that `theme dev` replaces your previous development theme ✅.
- Expecting checkout customizations to appear on `127.0.0.1:9292` ✅.

## Debugging

| Symptom | Likely cause | Fix |
|---|---|---|
| Local preview is blank | Wrong directory; missing `layout/theme.liquid` | Run from theme root |
| Changes not appearing | Live reload off; caching; editing the wrong theme | Check `--live-reload`; hard refresh; confirm theme ID |
| "Conflict" prompts | Editor and local both changed JSON | Choose `--reconciliation-strategy` deliberately |
| Dev link broken next day | Dev theme deleted after `auth logout` ✅ | Use `theme share` or push unpublished |
| Push fails validation | Invalid JSON/schema | Run `theme check`; fix errors |

## Performance / Accessibility / Security

- Performance: run Lighthouse against the preview before merging.
- Accessibility: include keyboard testing in the PR checklist.
- Security: no tokens in Git; limit store/app access to what the project needs.

## Production considerations

- Deploys during low-traffic windows; announce to the merchant.
- Keep a runbook: who deploys, how to roll back, who to call.

## Practice task

Create a dev store, run `shopify theme dev`, change a heading color in a section, and watch hot reload. Then run `shopify auth logout` and observe that the development theme disappears ✅ (confirm in the admin).

## Mini challenge

Write a push command that deploys everything **except** merchant-owned JSON, to an unpublished theme named `Staging <date>`.

## Interview questions

1. Why is Shopify CLI 2.x guidance unsafe to follow today? ✅ deprecated and unsupported.
2. What happens to the development theme when you log out? ✅ It is deleted.
3. How would you prevent overwriting merchant settings on deploy?
4. What's your rollback plan for a bad theme release, and what does it *not* cover?

## Checkpoint

- Can you run a full local → dev store → unpublished → publish cycle?
- Can you explain exactly what each command changes?
- Can you recover from a bad push?

## Further reading

- Shopify CLI theme commands: https://shopify.dev/docs/api/shopify-cli/theme
- `theme dev`: https://shopify.dev/docs/api/shopify-cli/theme/theme-dev
- Development stores: https://shopify.dev/docs/storefronts/themes/tools/development-stores

# 02 · Commerce Foundations for Developers

🟢 Beginner

> **Source layer:** this chapter rebuilds the merchant concepts from *Shopify for Beginners* (109 pp.) from a developer's perspective. Admin navigation labels in the PDF change over time, so treat them as ⚠️ **Verify** and rely on the *concepts*. See [legacy-and-outdated-shopify.md](legacy-and-outdated-shopify.md).

## What this is

The business vocabulary a Shopify developer must share with merchants: products, variants, collections, shipping, payments, taxes, customers, fulfillment, launch. For each, you get the **merchant view**, the **Shopify resource**, and **why a developer cares**.

## Why it matters

Clients speak in business terms ("a bundle", "free shipping over $100", "wholesale"). You translate those into Shopify resources and decide which layer implements them. If you mistranslate (for example, confusing product with variant), you build the wrong thing.

## Mental model

```mermaid
flowchart LR
    Biz[Business concept] --> Res[Shopify resource]
    Res --> Dev[Developer access]
    Dev --> Render[Storefront rendering]
    Render --> UX[Customer experience]
```

## The concept map

| Business concept (PDF topic) | Shopify resource | How a developer touches it |
|---|---|---|
| "A thing we sell" (PDF §6) | **Product** | `product` Liquid object; `Product` in GraphQL |
| "Size/color options" | **Option** and **Variant** | `product.variants`, `variant.price`, `variant.id` |
| Price, compare-at price, cost per item | Variant fields (cost lives on inventory item, admin-only) | `variant.price`, `variant.compare_at_price`. Cost is **not** exposed to the storefront. |
| Product type, vendor, tags | Product fields | `product.type`, `product.vendor`, `product.tags` |
| "Groups of products" (PDF §7) | **Collection** (manual or automated) | `collection.products`, pagination, filters |
| Inventory tracking, "Track quantity" | Inventory item and inventory level per location | Admin API; limited Liquid exposure via `variant.inventory_quantity` ⚠️ |
| Physical vs digital product (PDF §8) | `requires_shipping` on variant | `variant.requires_shipping` |
| Gift cards (PDF §8) | Gift card product type | Special handling in theme and checkout ⚠️ |
| Draft/Active, scheduled publishing | Product status and publication | Theme only renders what is published to the Online Store channel |
| Theme (PDF §9–15) | Theme resource | Chapter 04 |
| Shipping zones, rates, profiles (PDF "Configuring Shipping") | Delivery profiles, zones, rates | Mostly merchant config. Custom logic: delivery customization Functions (chapter 20). |
| Payments (PDF "Payment Gateways") | Payment providers | Not a theme concern. Checkout is Shopify-controlled. |
| Taxes | Tax settings | Merchant config. Display via price-includes-tax settings. |
| Customer import (CSV) | **Customer** | `customer` object; Admin API for programmatic work |
| Fulfillment, manual vs automatic | **Order**, **Fulfillment**, fulfillment orders | Admin API; webhooks react to changes |
| Test orders (Bogus Gateway) | Development/test payment mode | Chapter 27 (testing) ⚠️ |
| Launch checklist | Process | Production launch checklist (chapter 32) |
| Store password | Storefront password protection | Affects previews and CLI. `theme dev` accepts `--store-password`. ✅ |

## Developer perspective

### Product vs variant (the most common beginner error)

**Product**: the thing being merchandised (title, description, images, SEO).
**Variant**: a specific purchasable combination (price, SKU, inventory, barcode).

You do not add a *product* to cart. You add a *variant*. `product.id` and `variant.id` are different numbers, and the cart API expects the variant ID.

```liquid
{%- comment -%} Wrong: product.id is not purchasable {%- endcomment -%}
<input type="hidden" name="id" value="{{ product.id }}">

{%- comment -%} Right {%- endcomment -%}
<input type="hidden" name="id" value="{{ product.selected_or_first_available_variant.id }}">
```

### Collections: manual vs automated

The PDF calls automated collections "smart collections". Developers should know:

- Membership is computed by Shopify from rules. You do not store membership yourself.
- Theme code reads `collection.products` (paginated). Performance and filtering are covered in chapter 11.

### Merchant-owned vs developer-owned

| Merchant owns | Developer owns |
|---|---|
| Product data, prices, copy | Templates, sections, blocks |
| Shipping rates, taxes, payments | Frontend behavior, integrations |
| Theme settings values | Theme settings *definitions* (schema) |
| Policies | Policy page rendering |

Good developer work makes merchant-owned things editable without code. That is why [07 Sections and schema](00-roadmap.md) matters.

## Architecture: where each commerce concern is decided

```mermaid
flowchart TD
    P[Products/Variants/Collections] -->|Liquid, APIs| Theme
    S[Shipping/Tax/Payment settings] -->|Shopify checkout| Checkout
    C[Customers/Orders] -->|Admin API, webhooks| App
    Theme --> Cart --> Checkout
```

## Example: translating a client request

"Free shipping over $100, but not on gift cards."

| Question | Answer |
|---|---|
| Is it a theme change? | Only for the message ("You're $23 away"). Compute from `cart.total_price`. |
| Where is the rule enforced? | Shopify shipping rates (merchant config), possibly a delivery customization Function. |
| What must *not* be done? | Enforcing the rule only in JavaScript. The browser is not authoritative. |

## Common mistakes

- Trusting storefront JS for pricing, discounts, or shipping eligibility.
- Using admin labels from old tutorials as if they were stable APIs.
- Forgetting that markets/currencies change how price is displayed.
- Confusing "product tag" (free-form label) with "metafield" (typed, structured data).

## Debugging

- "Wrong price shown": check the variant, then market/currency context, then discounts at checkout.
- "Product missing from collection": check publication to the Online Store channel and collection rules.

## Production considerations

- Merchant admin screens evolve. Document **concepts and resource names** in client handoffs, not click paths.
- Verify tax, shipping, and payment behavior in a test environment; do not assume.

## Practice task

Pick any store. Write down, for one product: its variants, which variant is the default, what the compare-at price is, and which collections it belongs to. Then find the same data in the theme's product page HTML.

## Mini challenge

A product has options Size (S/M/L) and Color (Red/Blue). How many variants exist at most, and which ID goes to the cart?

## Interview questions

1. Product vs variant: which has a price? Which goes to the cart?
2. Why is "cost per item" not available to storefront JavaScript?
3. Manual vs automated collection: who maintains membership?

## Checkpoint

- Can you translate five merchant phrases into Shopify resources without notes?
- Can you explain why checkout rules cannot live only in theme JavaScript?

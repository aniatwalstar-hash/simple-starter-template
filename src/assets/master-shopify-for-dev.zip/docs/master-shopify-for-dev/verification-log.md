# Verification Log

Date of research: **2026-10-06**. Method: web search and fetch of shopify.dev pages. Entries marked ⚠️ were **not** confirmed against an official page in this release.

## Verified against official Shopify documentation ✅

| Claim | Source |
|---|---|
| Theme directory structure: `assets`, `blocks`, `config`, `layout`, `locales`, `sections`, `snippets`, `templates` (plus `templates/customers`, `templates/metaobject`); other subdirectories unsupported | https://shopify.dev/docs/storefronts/themes/architecture (fetched in full) |
| Only `layout/theme.liquid` is required for upload; a matching template is required for each page type you want to render | same |
| JSON templates act only as wrappers for sections; Liquid templates contain code | same |
| Section groups are JSON containers in `sections/` for header/footer areas | same |
| Snippets are invisible to merchants in the theme editor; LiquidDoc supported | same |
| `.liquid` asset files can access `settings` and filters | same |
| JSON comments/trailing commas supported in some files, not persisted in editor-written files (`templates/*.json`, section groups, `settings_data.json`, `locales/*.json`) | same |
| `templates/customers` = legacy customer account pages | same |
| Theme blocks live in `blocks/`, are reusable and nestable; sections accept them via `"blocks": [{ "type": "@theme" }]` and `{% content_for 'blocks' %}`; theme blocks and local blocks cannot be mixed in one section; static blocks via `content_for 'block'`; `@app` accepts app blocks | https://shopify.dev/docs/storefronts/themes/architecture/blocks/theme-blocks (search results) and the Shopify reference theme README |
| `theme dev` behavior, URL `127.0.0.1:9292`, live-reload modes, flags (`--store`, `--theme`, `--port`, `--host`, `--open`, `--only`, `--ignore`, `--nodelete`, `--allow-live`, `--environment`, `--theme-editor-sync`, `--reconciliation-strategy`, `--store-password`, `--password`), dev themes deleted on `auth logout`, checkout customizations not previewable locally | https://shopify.dev/docs/api/shopify-cli/theme/theme-dev (fetched in full) |
| CLI theme command names: `check`, `console`, `delete`, `dev`, `info`, `init`, `language-server`, `list`, `metafields pull`, `open`, `package`, `profile`, `publish`, `pull`, `push`, `rename`, `share` | https://shopify.dev/themes/tools/cli/commands (search result) |
| Shopify CLI 2.x is deprecated and no longer supported; use 3.x | https://shopify.dev/docs/storefronts/themes/tools/cli/cli-2/commands (search result) |
| REST Admin API is legacy as of Oct 1, 2024; new public apps must use GraphQL Admin API starting April 1, 2025; Admin API versions release four times per year | https://shopify.dev/docs/api/admin-rest (search results) |
| Development stores: created in Dev Dashboard; test data option; always password-protected; unlimited test orders/products; up to 10 custom apps; only free/Partner-friendly apps installable; some features block transfer | https://shopify.dev/docs/storefronts/themes/tools/development-stores and /docs/api/development-stores |
| `checkout.liquid` unsupported for Information, Shipping, Payment steps; deprecated for Thank you/Order status with sunset August 28, 2025 | https://shopify.dev/apps/checkout (search result) |

## Not verified / third-party only ⚠️

| Claim | Why unverified | Where it appears |
|---|---|---|
| Non-Plus checkout.liquid deadline (Aug 26, 2026) | Third-party blog only | legacy doc B5 |
| Shopify Scripts stop date (June 30, 2026) | Third-party blogs only | legacy doc B5, B6 |
| Functions run on WebAssembly; plan requirements for specific Functions/UI extensions | Third-party; plan rules change | chapters 19, 20 (planned) |
| `npm install -g @shopify/cli` as install command; `theme push` flags other than those shared with `dev` | Third-party skill pages; run `--help` | chapter 10 |
| `content_for_header` / `content_for_layout` requirements; Ajax Cart endpoint list; Section Rendering API details | General knowledge; not fetched this session | chapters 03, 04 |
| Latest stable API version number | Official pages in results showed 2026-01 and 2026-07 examples; confirm in versioning docs | chapters 13–15 (planned) |
| All PDF-derived pricing/plan/UI statements | Time-sensitive | legacy doc Part A |

## Next verification targets (before writing the planned chapters)

Liquid reference (tags, filters, objects), section schema reference (setting types, limits), Ajax Cart API and Section Rendering API, Storefront API versioning and auth, Admin GraphQL auth and rate limits, webhooks, app authentication and Dev Dashboard flow, theme app extensions, checkout UI extensions, Functions APIs, Hydrogen/Oxygen, customer accounts, Markets/localization, metafield and metaobject definitions.

# 04 · Theme Architecture

🟢 Beginner → 🟡 Intermediate

Verified against https://shopify.dev/docs/storefronts/themes/architecture on 2026-10-06 unless marked ⚠️.

## What this is

A reference for the directory structure of a Shopify theme, what every directory and file type is for, and what happens when you change it.

## Why it matters

Shopify enforces the theme structure. Files in unsupported places are not recognized. Knowing which file does what lets you find the right place for a change in seconds.

## Mental model

Think in three groups ✅ (Shopify's own categories):

1. **Markup and features**: `layout`, `templates`, `sections`, `blocks`, `snippets`. These generate HTML with Liquid.
2. **Supporting assets**: `assets`, `locales`. Called or consumed by other files.
3. **Config**: `config`. JSON that stores settings editable in the theme editor.

## Directory structure ✅

```text
theme/
├── assets/        CSS, JS, images, fonts
├── blocks/        theme-level blocks (reusable across sections)
├── config/        settings_schema.json, settings_data.json
├── layout/        theme.liquid (required)
├── locales/       translations
├── sections/      sections and section groups
├── snippets/      reusable Liquid fragments
└── templates/     page-type templates
    ├── customers/ legacy customer account templates
    └── metaobject/ templates for metaobject pages
```

Rules from the official docs ✅:

- Only a `layout` directory containing `theme.liquid` is required for upload.
- **Subdirectories other than the ones listed aren't supported.** You cannot create `assets/js/` as a nested folder inside the theme. Use flat file names with prefixes (for example `component-cart.js`).
- No templates are individually required, but you need a matching template for any page type you want to render (for example at least one `product` template to render product pages).

## Per-directory reference

### `layout/`

- **Purpose:** base wrapper for pages. Holds `<head>` content and section groups for header/footer.
- **Example:** `layout/theme.liquid`.
- **Use when:** content is repeated on every page (meta tags, global scripts, header/footer groups).
- **Do not use when:** the content belongs to one page type (put it in a template/section).
- **Relationships:** templates render through the layout.
- **If you edit it:** every page changes. A syntax error here can break the whole storefront. Always test on a development theme first.
- ⚠️ A layout must output `{{ content_for_header }}` in `<head>` and `{{ content_for_layout }}` in `<body>`. Confirm on the layouts page.

### `templates/`

- **Purpose:** controls what renders for each page type (home, product, collection, cart, page, blog, article, search, 404, password, gift card, etc.).
- **Two kinds ✅:** JSON templates (wrappers for sections; no Liquid logic) and Liquid templates (contain code).
- **Alternate templates ✅:** multiple templates for the same resource type, assigned per resource (for example `product.landing.json`).
- **Use JSON when:** merchants should add/reorder sections.
- **Use Liquid template when:** the page is fixed (some utility pages) and does not need merchant layout control.
- **If you edit it:** only pages using that template change.
- **`templates/customers/` ✅:** templates for **legacy** customer account pages such as login and account overview. ⚠️ Check the current customer account model (new vs classic) before building here.
- **`templates/metaobject/` ✅:** supports metaobject pages (see chapter 12).

### `sections/`

- **Purpose:** reusable, merchant-customizable modules; also **section groups** (JSON) for header/footer areas ✅.
- **Example:** `sections/featured-collection.liquid`, `sections/header-group.json`.
- **Use when:** merchant should add, remove, reorder, or configure it.
- **Do not use when:** you only need an internal, non-editable fragment (use a snippet).
- **If you edit it:** every template instance using it changes. Schema changes can invalidate existing merchant settings. Never rename a setting `id` without a migration plan.

### `blocks/` ✅

- **Purpose:** **theme blocks**: blocks defined at theme level, reusable across sections and nestable in other blocks.
- **Mechanics ✅:** a block file resembles a section (Liquid body + `{% schema %}`). A section accepts them via `"blocks": [{ "type": "@theme" }]` and `{% content_for 'blocks' %}`. App blocks are accepted with `{ "type": "@app" }`.
- **Static usage ✅:** `{% content_for 'block', type: 'slideshow-controls', id: 'slideshow-controls' %}`.
- **Constraint ✅:** a section cannot mix theme blocks and section-local blocks.
- **Use when:** you want a component (for example a `text` or `button` block) reused in many sections.
- **Do not use when:** a block only makes sense inside one section and you do not need reuse (local blocks are simpler).

### `snippets/`

- **Purpose:** reusable Liquid fragments, **invisible to merchants in the theme editor** ✅.
- **Call with:** `{% render 'name', param: value %}`.
- **Use when:** shared markup or logic (price display, icon, product card).
- **Do not use when:** merchants must configure it (needs a section/block with schema).
- **Tooling ✅:** you can add **LiquidDoc** definitions to document parameters and enable editor support.
- **If you edit it:** every file that renders it changes.

### `assets/`

- **Purpose:** CSS, JS, images, fonts.
- **Reference with:** `{{ 'base.css' | asset_url | stylesheet_tag }}`.
- **Liquid in assets ✅:** appending `.liquid` (for example `theme.css.liquid`, `app.js.liquid`) gives limited Liquid: the `settings` object and filters.
- **Use `.liquid` assets when:** a stylesheet needs theme setting values. 📘 Prefer CSS variables set in `layout` or a section `{% style %}`/`{% stylesheet %}` for most cases.
- **If you edit it:** all pages that load it change; browsers/CDNs cache by URL, so confirm you are viewing the new version.

### `config/` ✅

- `settings_schema.json`: **defines** global theme settings shown in the theme editor.
- `settings_data.json`: **stores** the merchant's values.
- **If you edit `settings_data.json` locally and push:** you can overwrite the merchant's saved settings. Use `--ignore` on push for files you do not want to overwrite. See [10 CLI + Git](10-shopify-cli-git.md).
- **Accessing values:** the `settings` Liquid object.

### `locales/` ✅

- Translation files, used for the storefront, the theme editor, and merchant-editable theme text. Also schema translation files (for example `en.default.schema.json`) for editor labels.
- **Use when:** every user-facing string. 📘 Hardcoded English in Liquid is a maintenance bug.

## JSON with comments ✅

Shopify allows comments and trailing commas in some theme JSON, for example `config/settings_schema.json` and inside schema tags. Files that merchants typically edit through the editor do **not** persist comments or trailing commas:

```text
templates/*.json
sections/*.json   (section groups)
config/settings_data.json
locales/*.json
```

📘 Practical consequence: your formatter, linter, or script must tolerate comments; do not put important documentation in comments inside those editor-written files.

## Component relationship summary

```mermaid
flowchart TD
    L[layout/theme.liquid] --> SG[section groups: header/footer]
    L --> T[templates/*.json]
    T --> S[sections/*.liquid]
    SG --> S
    S --> B[blocks: local or blocks/*.liquid]
    S --> SN[snippets]
    B --> SN
    S --> A[assets]
    S --> LO[locales]
    S --> CF[config/settings]
```

## "What happens if I edit this file?" cheat table

| File | Blast radius | Risk |
|---|---|---|
| `layout/theme.liquid` | Every page | 🔴 Highest |
| `snippets/*.liquid` | Every file rendering it | 🟠 |
| `sections/*.liquid` | Every template instance using it | 🟠 |
| `templates/product.json` | Product pages using it | 🟡 |
| `assets/*.css` / `*.js` | Every page loading it | 🟠 |
| `config/settings_data.json` | Merchant's saved values | 🟠 (data loss risk) |
| `locales/*.json` | Strings in that language | 🟡 |

## Common patterns

- One section, one responsibility; shared bits as snippets or theme blocks.
- Schema-driven: every merchant-facing choice is a setting, not a hardcoded value.
- Namespaced asset names: `component-*.css`, `section-*.css`, `*.js` modules, since subfolders are not allowed ✅.

## Common mistakes

- Creating unsupported subfolders (for example `assets/js/`) and wondering why files are not found.
- Putting merchant-editable content in snippets.
- Mixing theme blocks and local blocks in one section.
- Overwriting `settings_data.json` on deploy.
- Renaming section/setting IDs after merchants have saved content.

## Debugging

| Symptom | Check |
|---|---|
| Upload rejected | Is there `layout/theme.liquid`? Any unsupported directory? |
| Section missing in editor | Does it have a valid `{% schema %}` and `presets` (if it should be addable)? ⚠️ |
| Asset 404 | File name and extension; referenced via `asset_url`? |
| Editor labels show keys | Missing schema locale file (`*.schema.json`) ⚠️ |

Run `shopify theme check` (chapter 10) to catch many structural problems.

## Performance

- Fewer, leaner sections beat many wrappers. Each rendered section costs server time and DOM.
- Load JS only where needed (section-level script tags) rather than globally in `layout`.

## Accessibility

- Layout owns `<main>`/landmarks; sections own headings; do not duplicate `<h1>` across sections.

## Security

- Do not place secrets in `assets` or Liquid. Theme files are served to browsers.

## Production considerations

- Keep the theme in Git. Never edit the published theme directly in the code editor for non-trivial changes.
- Treat schema as a public contract with merchants' saved data.

## Practice task

Create (or download) a Dawn copy. For each directory, open one file and write one sentence on how it relates to the product page.

## Mini challenge

Add a `blocks/text.liquid` theme block, and make a section accept it with `@theme`. Then try adding a local block to the same section and observe the constraint.

## Interview questions

1. Which single file is required for a theme upload? ✅ `layout/theme.liquid`.
2. What is the difference between a section and a snippet from the merchant's point of view?
3. Why can't you create `assets/js/`? ✅ unsupported subdirectories.
4. What do theme blocks give you that local blocks don't? ✅ reuse across sections and nesting.

## Checkpoint

- Can you draw the directory tree and label each folder's purpose?
- Can you predict the blast radius of editing each file?
- Can you explain why `settings_data.json` is dangerous to push blindly?

## Further reading

- Theme architecture: https://shopify.dev/docs/storefronts/themes/architecture
- Theme blocks: https://shopify.dev/docs/storefronts/themes/architecture/blocks/theme-blocks

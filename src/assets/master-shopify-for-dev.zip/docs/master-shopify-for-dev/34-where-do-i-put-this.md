# 34 · "Where Do I Put This?"

🟡 Intermediate

Markers: ✅ verified 2026-10-06 · ⚠️ confirm on shopify.dev.

## What this is

A lookup table: for any "I need to…" requirement, the correct Shopify place for it.

## How to use it

1. Find your requirement in the left column.
2. Read the **place**, then the **why**.
3. Follow the link to the chapter for the how.

## The guide

| I need to… | Put it in | Why | Chapter |
|---|---|---|---|
| Change visual markup of an existing page | Theme: section/snippet/template | Liquid renders HTML on Shopify ✅ | 04, 08 |
| Add repeated header/footer content | `layout/` or section groups | Layout repeats; section groups make it editable ✅ | 04 |
| Create configurable content blocks for merchants | Section/block **schema** | Schema drives the theme editor ✅ | 07 |
| Reuse a block type across sections | **Theme block** in `blocks/` | Reusable and nestable ✅ | 04 |
| Add global color/typography settings | `config/settings_schema.json` | Theme settings ✅ | 04 |
| Reuse markup without merchant editing | Snippet | Snippets are invisible in the editor ✅ | 04 |
| Add translated text | `locales/*.json` | i18n ✅ | 04 |
| Store extra structured product data (specs, ingredients) | **Metafield** | Typed field attached to a resource | 12 |
| Store reusable structured content (team, FAQs, stores) | **Metaobject** | Standalone, reusable entries; can have pages ✅ (`templates/metaobject/`) | 12 |
| Add/modify cart behavior on the storefront (drawer, quantity UI) | Theme JS calling the Ajax Cart API | Cart is Shopify-held; theme is the UI ⚠️ | 11 |
| Enforce a business rule (min quantity, eligibility) | **Shopify Functions** / checkout validation ⚠️ | The browser is not authoritative | 20 |
| Custom discount logic | **Discount Function** ⚠️ | Computed by Shopify | 20 |
| Customize checkout UI (banner, field, upsell) | **Checkout UI extension** ⚠️ | Checkout isn't a theme file; extensibility is the supported path ✅ | 19 |
| Style checkout | Checkout branding / editor ⚠️ | Not CSS in a theme | 19 |
| Access private Shopify data (orders, customers, cost) | **Server-side app** with Admin API | Needs credentials | 14, 17 |
| Read public catalog data from a custom frontend | Storefront API | Designed for public storefront access | 13 |
| Call an external system with a secret | App/backend | Secrets cannot be in browser or theme | 25 |
| React to Shopify events (order paid, product updated) | **Webhook** handled by an app | Event-driven integration | 16 |
| Run background jobs / sync | App server | Themes cannot run background work | 17 |
| Add a merchant-placeable storefront widget from an app | **Theme app extension** (app block) ✅ | Merchant adds it in the editor; no theme code edits | 18 |
| Add a global script from an app (analytics, chat) | **App embed** ✅ | Merchant toggles it | 18 |
| Add an admin screen or admin action | Admin extension / embedded app ⚠️ | Admin UI is app territory | 17 |
| Build a completely custom frontend | **Headless** | Only when the theme system can't express it | 21, 33 |
| Redirect old URLs | Shopify URL redirects (merchant/admin config) ⚠️ | Platform feature | 23 |
| Add structured data (JSON-LD) | Theme (Liquid) | Rendered HTML, SEO-visible | 23 |
| Measure performance | Browser tools, Lighthouse, field data | 📘 | 22 |
| Test without touching production | Dev store + unpublished theme ✅ | Isolation | 10 |

## Quick tie-breakers

- **Secret involved?** App/server. Never theme.
- **Needs to survive theme changes?** App extension, not theme edits.
- **Merchant must edit it?** Schema/metafield/metaobject.
- **Must be trustworthy (price, eligibility)?** Shopify-side logic (cart/checkout/Functions), not browser JS.
- **Presentation only?** Theme.

## Common mistakes

- Putting API keys "just for now" in theme JS.
- Putting merchant-editable text in a snippet.
- Calling a client-side check "validation".
- Building an app when a metafield and a section would do.

## Checkpoint

Pick five features from a client brief and place each without looking at this table.

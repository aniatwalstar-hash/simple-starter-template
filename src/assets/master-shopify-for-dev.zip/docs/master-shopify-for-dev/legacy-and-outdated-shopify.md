# Legacy and Outdated Shopify

This file records (a) statements in the source PDF that are time-sensitive or likely outdated, and (b) historical developer approaches that old tutorials still teach. Nothing in the PDF has been silently rewritten: each entry quotes or paraphrases what the PDF said and then states the current position.

**Status labels**

- 🏛️ **HISTORICAL**: confirmed by official docs as deprecated, legacy, or sunset.
- ⚠️ **TIME-SENSITIVE**: plausible to have changed; **not confirmed either way in this release**. Verify before using or repeating to a client.
- ✅ **CONFIRMED CURRENT**: checked against official docs.

Review date: 2026-10-06. The PDF content dates from roughly 2024 (it refers to a "Shopify 2024 CRO Checklist").

---

## Part A: Statements in the PDF

| # | PDF said (page) | Status | Why it may not apply | Current approach / action | Official source |
|---|---|---|---|---|---|
| A1 | Plans "start at $5 per month (Starter Plan)" and "five Shopify plans" (p. 6, 14) | ⚠️ TIME-SENSITIVE | Pricing and plan lineup change | Check the live pricing page; do not quote prices from the PDF | https://www.shopify.com/pricing |
| A2 | "3-day free trial" with an offer to extend for 30 days for $1 (p. 7) | ⚠️ TIME-SENSITIVE | Promotion; time-bound | Treat as historical promotion | Shopify pricing/trial page |
| A3 | Sign-up through a third-party vendor's landing page for bonus perks (pp. 7–8) | ⚠️ TIME-SENSITIVE (promotional) | Vendor promotion, not Shopify documentation | Excluded from the curriculum. For developers: use the **Dev Dashboard** to create a development store ✅ | https://shopify.dev/docs/storefronts/themes/tools/development-stores |
| A4 | "The Dawn theme is pre-installed on all Shopify stores with the Basic plan or higher" (p. 35) | ⚠️ TIME-SENSITIVE | Default theme for new stores may change | Check the Themes page in admin; use the Dawn repository as a *reference* for architecture ✅ | https://github.com/Shopify/dawn |
| A5 | "Spotlight theme only on the Starter plan" (p. 36) | ⚠️ TIME-SENSITIVE | Plan/theme eligibility changes | Verify in admin | Shopify Help Center |
| A6 | "200 paid themes ranging $140 to $450" (p. 37) | ⚠️ TIME-SENSITIVE | Catalog and prices change | Verify in Theme Store | https://themes.shopify.com |
| A7 | "You can add up to 20 themes… only one published" (p. 41) | ⚠️ TIME-SENSITIVE | Library limits can change | Verify; developer workflow uses development and unpublished themes ✅ (chapter 10) | Shopify Help Center |
| A8 | Customization instructions: logo/colors in "Theme Settings > Colors", "Header section" (pp. 42–46) | ⚠️ TIME-SENSITIVE | Editor labels vary by theme and version | For developers: these are **settings defined in `config/settings_schema.json` and section schemas** ✅. Labels are whatever the theme author wrote | https://shopify.dev/docs/storefronts/themes/architecture |
| A9 | Shipping: "pre-negotiated carrier rates with up to 88% discounts" (p. 50) | ⚠️ TIME-SENSITIVE | Carrier programs and regions change | Do not repeat figures; verify per region | Shopify Help Center |
| A10 | Navigation paths such as "Settings > Shipping and delivery", "Settings > Taxes and duties", "Settings > General > Order processing" (pp. 50–72) | ⚠️ TIME-SENSITIVE | Admin navigation is revised regularly | Learn **resource names**; look up current click paths when needed | Shopify Help Center |
| A11 | "Shopify Fulfillment Network if you're based in the US or Canada" (p. 70) | ⚠️ TIME-SENSITIVE (strong suspicion of discontinuation) | General knowledge suggests Shopify's logistics offering was wound down; **not verified here** | Do not recommend SFN; use current fulfillment services/apps | Shopify Help Center / App Store |
| A12 | "Bogus Gateway": card number `1` success, `2` fail, `3` exception; deactivate other providers first (pp. 80–83) | ⚠️ TIME-SENSITIVE | Testing options differ by store type and plan | On development stores, Shopify documents test orders ✅ (unlimited test orders); confirm the exact current test-payment method | https://help.shopify.com/en/partners/dashboard/managing-stores/test-orders-in-dev-stores |
| A13 | Digital products require adding the "Digital Downloads" app (pp. 30–31) | ⚠️ TIME-SENSITIVE | App availability and naming change | Verify in App Store; for developers, digital delivery is an app/fulfillment concern | Shopify App Store |
| A14 | "Store is password-protected during the free trial; remove via Online Store > Preferences" (pp. 85–86) | ⚠️ TIME-SENSITIVE | Admin paths change | Conceptually unchanged: storefront password affects previews and the CLI (`--store-password`) ✅ | https://shopify.dev/docs/api/shopify-cli/theme/theme-dev |
| A15 | "Customize… the Checkout page" in the theme editor (p. 45) | 🏛️/⚠️ | Checkout is **not a theme file**; customization goes through checkout extensibility | See chapter 19. Checkout is not previewable at `127.0.0.1:9292` ✅ | https://shopify.dev/docs/storefronts/themes/tools/cli (see `theme dev`) |
| A16 | "Use AI-powered SEO tools", "Use Shopify's Google Shopping integration" (p. 91) | ⚠️ TIME-SENSITIVE | Tools and integrations change | SEO engineering is covered from first principles in chapter 23 | n/a |
| A17 | Facebook/Instagram channel setup steps (pp. 104–106) | ⚠️ TIME-SENSITIVE | Channel apps and Meta requirements change frequently | Out of developer scope | App Store |

---

## Part B: Historical developer approaches (not in the PDF, but common in old tutorials)

| # | Historical approach | Status | What replaced it | Official source |
|---|---|---|---|---|
| B1 | **Shopify CLI 2.x** (`shopify theme serve`, `shopify theme init` flows from 2.x) | 🏛️ HISTORICAL ✅ | Shopify CLI 3.x and the current `shopify theme` commands (`dev`, `pull`, `push`, `check`, `share`, `publish`, …) | https://shopify.dev/docs/api/shopify-cli/theme |
| B2 | **REST Admin API for new work** | 🏛️ HISTORICAL/LEGACY ✅ ("legacy API as of October 1, 2024") | **GraphQL Admin API**. Since April 1, 2025, new public apps must be built exclusively with GraphQL ✅ | https://shopify.dev/docs/api/admin-rest |
| B3 | **`checkout.liquid`** for Information/Shipping/Payment steps | 🏛️ HISTORICAL ✅ ("unsupported") | Checkout extensibility | https://shopify.dev/docs/apps/build/checkout |
| B4 | `checkout.liquid`, additional scripts, script tags on **Thank you / Order status** pages | 🏛️ HISTORICAL ✅ (official page states sunset **August 28, 2025**) | Checkout UI extensions and related extension points | https://shopify.dev/docs/apps/build/checkout |
| B5 | Other checkout.liquid / Shopify Scripts dates reported by third-party sources (for example non-Plus deadline Aug 26, 2026; Scripts stopping June 30, 2026) | ⚠️ UNVERIFIED (third-party only) | Confirm on shopify.dev and the Shopify help center *for the specific store's plan* before advising a client | Shopify Help Center "checkout upgrade" |
| B6 | **Shopify Scripts** (Script Editor) | ⚠️ Deprecation reported; confirm | **Shopify Functions** (chapter 20) | https://shopify.dev/docs/apps/build/functions |
| B7 | `{% include %}` tag | 🏛️ legacy pattern ⚠️ (confirm current wording) | `{% render %}` (isolated scope, explicit parameters) | https://shopify.dev/docs/api/liquid |
| B8 | Theme files **without** JSON templates (all-Liquid `templates/*.liquid`) for pages merchants should customize | 🏛️ legacy pattern | JSON templates with sections ✅ (JSON templates act as wrappers for sections) | https://shopify.dev/docs/storefronts/themes/architecture/templates |
| B9 | `templates/customers/*` (customer account Liquid templates) | ✅ marked **legacy** in official docs ("legacy customer account pages") | Current customer accounts model; verify before building | https://shopify.dev/docs/storefronts/themes/architecture |
| B10 | Nested folders under `assets/` | ✅ **unsupported** (only listed subdirectories are supported) | Flat file names with prefixes | https://shopify.dev/docs/storefronts/themes/architecture |

---

## How to use this file

1. If a tutorial uses something in Part B, check the status here before copying anything.
2. If a client quotes something from the PDF in Part A, verify it before acting on it.
3. When a ⚠️ item is verified, move it to ✅ or 🏛️ and add the date and URL. Track in [verification-log.md](verification-log.md).

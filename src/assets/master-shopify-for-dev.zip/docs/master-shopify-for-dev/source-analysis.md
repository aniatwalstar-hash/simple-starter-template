# Source Analysis: *Shopify for Beginners* (109 pp.)

Source file: `shopify-for-beginners.pdf` · 109 pages · Google Docs export · text layer present (fully extractable) · published with promotional content from a third-party app vendor and references to 2024-era Shopify pricing and UI.

The PDF is a **merchant onboarding guide**. It contains **no developer content**: no Liquid, theme code, CLI, APIs, apps, or architecture. That is the central finding. The PDF is the foundation of the *business/storefront learning layer* only.

## 1. What the PDF explains well

- A linear merchant journey from sign-up to launch (account → products → collections → themes → shipping → payments → taxes → customers → fulfillment → testing → launch → marketing).
- Plain-language product data entry (title, description, media, price, compare-at price, product type, vendor, tags, inventory tracking, shipping weight, HS code).
- Collections (manual and rule-based) and practical organization tips.
- Theme customization from the editor: logo, colors, images, sections.
- Order fulfillment choices (self-fulfill vs services; manual vs automatic; partial fulfillment).
- Test-order approaches and a launch checklist.

## 2. What it explains only at merchant level

Products, collections, themes ("customize"), shipping zones/rates, payments, taxes, customers (CSV import), fulfillment, SEO, content/marketing. All are click-path tutorials without data models, objects, or code access.

## 3. What is technically outdated or time-sensitive ⚠️

See [legacy-and-outdated-shopify.md](legacy-and-outdated-shopify.md). Highlights: plan names/prices, trial promotions, default theme claims, admin navigation labels, fulfillment network references, theme count limits, test-gateway details.

## 4. What is missing for developers

Theme architecture, Liquid, objects/data model, sections/schema, CLI/Git, JS/Cart API, metafields/metaobjects, APIs/GraphQL/webhooks, apps/extensions, checkout extensibility, Functions, headless, performance engineering, accessibility, security, debugging, testing, deployment.

## 5–7. Retain / compress / expand

| Decision | Topics |
|---|---|
| **Retain** | Product, collection, shipping, payment, tax, customer, fulfillment concepts; launch checklist ideas; terminology (Product type, Vendor, Collection, Compare at price, Fulfillment, Shipping zone, Shipping profile, Bogus Gateway, Storefront password) |
| **Compress** | Sign-up walkthrough, plan selection, payment-provider activation steps, tax registration steps, marketing channels, social selling |
| **Expand heavily** | Themes (PDF pp. 35–47) → theme architecture + Liquid + schema; products/collections (pp. 15–29) → data model + Liquid + APIs; storefront (pp. 41–47) → rendering lifecycle; fulfillment/orders (pp. 68–78) → Orders/Fulfillment APIs + webhooks; testing (pp. 79–84) → automated + manual testing; SEO (p. 91) → SEO engineering |

## 8. Concepts requiring official verification

Everything about: current plans and trials, default/free themes, theme limits, Shopify Payments availability, tax setup labels, fulfillment network availability, shipping discount claims, test gateway behavior, social channel integrations, checkout customization, customer accounts. Tracked in [verification-log.md](verification-log.md).

## 9. Terminology preserved

Product, Variant, Collection (manual/automated), Product type, Vendor, Tags, Compare at price, Cost per item, Track quantity, HS code, Digital product, Gift card, Theme, Theme library, Customize, Storefront password, Shipping zone/rate/profile, Fulfillment (manual/automatic/partial), Fulfillment service, Test order, Bogus Gateway, Legal pages.

## 10. Concepts re-explained from a developer perspective

| Merchant term | Developer meaning |
|---|---|
| "Customize" | Theme editor writes JSON (templates/section groups/settings) that sections read via `section.settings` / `settings` |
| "Tags" | Free-form strings (`product.tags`), distinct from typed metafields |
| "Collections" | Rule/manual sets with Liquid/API access, pagination, filtering |
| "Product images" | Media resources with responsive image filters |
| "Fulfillment" | Orders → fulfillment orders → fulfillments, event-driven via webhooks |
| "Storefront password" | Affects previews and CLI access (`--store-password`) |

---

## Section-by-section mapping

| PDF section (page) | Keep | Expand | Replace / Compress | New developer topic | Target doc |
|---|---|---|---|---|---|
| 1. What is this? (5) | ✓ | | Compress | Orientation | README |
| 2. Why you need an online store (5–6) | | | Compress | Business rationale kept as one paragraph | 02 |
| 3. Why choose Shopify (6–7) | ✓ | | Compress; pricing ⚠️ | What Shopify is technically | 01, README |
| 4. Avada deals (7–8) | | | **Replace** (promotional, time-bound) | n/a | legacy doc |
| 5. Creating account (8–14): sign-up, plan | ✓ | | Compress | Dev store creation via Dev Dashboard ✅ | 10 |
| 6. Adding products (15–26) | ✓ | ✓✓ | | Product/variant data model, Liquid product object, Admin API product | 02, 06, 11, 14 |
| 7. Collections (27–29) | ✓ | ✓✓ | | Collection Liquid, pagination, filtering, Storefront API | 02, 11 |
| 8. Digital products and gift cards (30–34) | ✓ | ✓ | App dependency ⚠️ | `requires_shipping`, gift card handling, fulfillment automation | 02, 11 |
| 9. Selecting a theme (35–40) | ✓ | ✓✓✓ | | Theme architecture, zip upload vs CLI/Git | 04, 10 |
| 10–15. Customizing storefront (41–47) | ✓ | ✓✓✓ | | Sections/blocks/schema, settings, theme editor ↔ JSON | 03, 07 |
| Best practices for storefront design (47–48) | ✓ | ✓ | | Frontend engineering, a11y, performance | 09, 22, 24 |
| 9. Configuring shipping (48–54) | ✓ | ✓ | Click paths compressed | Delivery profiles/zones in the data model; delivery customization Functions | 02, 06, 20 |
| Setting up payment gateways (55–61) | ✓ | ✓ | Steps compressed ⚠️ | Integration boundaries: checkout is Shopify's | 02, 19 |
| Managing taxes (61–63) | ✓ | ✓ | | Price display and tax-inclusive settings in Liquid; boundary | 02 |
| Importing customer data (64–67) | ✓ | ✓ | | Customer model, CSV vs Admin API, privacy | 06, 14, 25 |
| Order fulfillment and management (68–78) | ✓ | ✓✓ | SFN reference ⚠️ | Orders/fulfillment APIs, webhooks | 14, 16 |
| Testing before launch (79–84) | ✓ | ✓✓ | Gateway details ⚠️ | Test strategy, automated testing, test orders in dev stores | 27 |
| Launching your store (84–90) | ✓ | ✓ | | Production launch checklist, password removal ✅ context | 28, 32 |
| Marketing (90–103) | ✓ | Minimal | Compress | SEO engineering (23); analytics/pixels boundaries | 23 |
| Social channels (104–107) | | Minimal | Compress | Channel/app boundary | 17 |
| Resources and support (108–109) | ✓ | | Replace with official dev resources | Official docs, community | README |

## Gap list (new developer content with no PDF source)

Theme architecture · Liquid language · Liquid object model · Section schema · Theme blocks · Shopify CLI · Git workflows · JavaScript/Cart API · Metafields/metaobjects · Admin/Storefront APIs · GraphQL · Webhooks · Apps · Theme app extensions · Checkout extensibility · Functions · Headless · Accessibility · Security · Debugging · Interview prep. These are sourced from official Shopify docs (Tier 1) and general engineering knowledge (Tier 3).

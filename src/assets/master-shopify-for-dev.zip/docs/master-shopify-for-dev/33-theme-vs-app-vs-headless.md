# 33 · Theme vs App vs Headless

🟡 Intermediate

Markers: ✅ verified on shopify.dev 2026-10-06 · ⚠️ depends on current platform rules; verify before committing to a client.

## What this is

A decision framework for choosing the primary technical approach for a requirement.

## Why it matters

The wrong choice is expensive: a headless build where a theme was enough costs months; a theme hack where an app was needed produces insecure or fragile code.

## Mental model

```mermaid
flowchart TD
    Q[Requirement] --> V{Only changes how the<br/>storefront looks/behaves<br/>using Shopify data?}
    V -- yes --> TH[Theme]
    V -- no --> S{Needs secrets, external systems,<br/>background work, or admin UI?}
    S -- yes --> AP[App]
    S -- no --> C{Needs a frontend the theme<br/>system cannot express?}
    C -- yes --> HL[Headless]
    C -- no --> TH
    AP --> X{Needs to show UI on the storefront?}
    X -- yes --> EXT[App + theme app extension / app embed]
```

## The matrix

| Requirement | Theme | App | Headless |
|---|---|---|---|
| Visual customization | ✓ best fit | Sometimes (via app blocks/embeds) | ✓ unlimited, you build everything |
| Merchant-configurable sections | ✓ sections/blocks + schema ✅ | ✓ via theme app extension app blocks ✅ | Custom: you build your own editing story |
| Reading Shopify data for display | ✓ Liquid objects | ✓ APIs | ✓ Storefront API |
| External service integration (CRM, ERP) | Limited (client-side calls only, no secrets) | ✓ server-side | ✓ via your backend |
| Private/secret API access | **No** | ✓ | Server only |
| Advanced commerce logic (discount rules, validation) | Limited | ✓ via Functions ⚠️ | Depends; checkout logic still Shopify's ⚠️ |
| Full frontend control | Limited to theme system | Limited | ✓ |
| Fast implementation | ✓ | Medium | Complex |
| Maintenance burden | Low–medium | Medium | High (you own hosting, caching, SEO, previews) |
| SEO by default | Strong (server-rendered by Shopify) | n/a | You must engineer it (SSR, canonicals, sitemaps) |
| Checkout customization | Not via theme ✅ | ✓ via checkout extensions ⚠️ | Still Shopify checkout ⚠️ |

⚠️ Cells marked with a warning change with platform rules (for example plan requirements for checkout customization). Always confirm on shopify.dev and with the merchant's Shopify plan.

## Decision rules 📘

1. **Default to a theme.** Reach for app or headless only when a *specific* constraint forces it.
2. **If it needs a secret, it needs a server.** That means an app (or your own backend).
3. **If it must react to Shopify events** (order paid, product updated), you need webhooks, so an app/server.
4. **If it must show on the storefront and be merchant-placeable**, pair the app with a **theme app extension** (app block or embed) instead of editing theme code ✅ (see chapter 18).
5. **Headless only with a written justification** (see below).

## When headless is justified 📘

- Multiple frontends (web + native + kiosk) sharing one storefront data layer.
- A product experience the theme system genuinely cannot express (for example highly custom 3D configurators), after confirming a theme + JS cannot do it.
- An existing frontend platform and team that will own hosting, caching, SEO, previews.

## When headless is unnecessary 📘

- "We want a fast site": a well-built theme can be fast.
- "We want a custom design": themes support extensive design control.
- "Our developer likes React": not a business reason.

## Example scenarios

| Scenario | Choice | Why |
|---|---|---|
| Sticky add-to-cart bar | Theme | Presentation + cart API; no secrets |
| Show live ERP stock levels | App (server proxy) + theme/extension display | ERP credentials must stay server-side |
| Custom product specs table | Theme + metafields | Structured merchant data, rendered in Liquid |
| Wholesale tier discounts | App/Function ⚠️ | Pricing logic enforced by Shopify, not by browser JS |
| Review system | Existing app via app block, or custom app | Needs storage and moderation |
| Native mobile storefront | Headless/mobile APIs ⚠️ | Not expressible as a theme |

## Common mistakes

- Choosing headless for performance without measuring the theme first.
- Implementing pricing rules in JavaScript.
- Editing theme code for what should be an app block (breaks on theme updates).

## Checkpoint

- Can you place any new requirement on the flowchart in under a minute?
- Can you defend a headless proposal with a specific constraint?

# 00 · Roadmap and Curriculum Map

🟢 Beginner

## What this is

The curriculum plan: every chapter, its prerequisites, its level, and what the learner must be able to do before moving on.

## Why it matters

Shopify has many surfaces (themes, APIs, apps, checkout, Functions, headless). Learning them out of order produces developers who copy snippets without understanding boundaries. The ordering rule here is: **do not teach a layer until its dependency layer is understood.**

## Dependency graph

```mermaid
flowchart TD
    M[01 Mental model] --> C[02 Commerce foundations]
    C --> S[03 Storefront architecture]
    S --> T[04 Theme architecture]
    T --> L[05 Liquid]
    L --> D[06 Data model]
    D --> SC[07 Sections + schema]
    SC --> TD[08 Theme dev] --> FE[09 HTML/CSS/JS]
    FE --> CLI[10 CLI + Git]
    CLI --> CART[11 Products/collections/cart]
    CART --> MF[12 Metafields + metaobjects]
    MF --> SAPI[13 Storefront API]
    MF --> AAPI[14 Admin API]
    SAPI --> GQL[15 GraphQL]
    AAPI --> GQL
    GQL --> WH[16 Webhooks]
    WH --> APP[17 Apps]
    APP --> EXT[18 Theme app extensions]
    APP --> CHK[19 Checkout extensibility]
    CHK --> FN[20 Functions]
    SAPI --> HL[21 Headless]
    EXT --> PERF[22-27 Cross-cutting quality]
    PERF --> DEP[28 Deployment] --> PROD[29 Production architecture]
    PROD --> PROJ[30 Projects]
```

## Chapter plan

| # | Chapter | Level | Prereq | Status |
|---|---|---|---|---|
| 01 | Shopify mental model | 🟢 | none | ✅ |
| 02 | Commerce foundations (from PDF) | 🟢 | 01 | ✅ |
| 03 | Storefront architecture and page lifecycle | 🟢 | 02 | ✅ |
| 04 | Theme architecture | 🟢 | 03 | ✅ |
| 05 | Liquid | 🟢→🟡 | 04 | 🚧 |
| 06 | Data model | 🟡 | 05 | 🚧 |
| 07 | Sections and schema | 🟡 | 05, 06 | 🚧 |
| 08 | Theme development | 🟡 | 07 | 🚧 |
| 09 | HTML, CSS, JavaScript for Shopify | 🟡 | 08 | 🚧 |
| 10 | Shopify CLI and Git | 🟡 | 04 | ✅ |
| 11 | Products, collections, cart | 🟡 | 09 | 🚧 |
| 12 | Metafields and metaobjects | 🟡 | 06, 07 | 🚧 |
| 13 | Storefront API | 🟠 | 11, 12 | 🚧 |
| 14 | Admin API | 🟠 | 12 | 🚧 |
| 15 | GraphQL | 🟠 | 13 or 14 | 🚧 |
| 16 | Webhooks | 🟠 | 14 | 🚧 |
| 17 | App development | 🟠 | 14–16 | 🚧 |
| 18 | Theme app extensions | 🟠 | 17 | 🚧 |
| 19 | Checkout extensibility | 🔴 | 17 | 🚧 |
| 20 | Shopify Functions | 🔴 | 19 | 🚧 |
| 21 | Headless Shopify | 🔴 | 13 | 🚧 |
| 22–27 | Performance, SEO, accessibility, security, debugging, testing | 🟠 | 09+ | 🚧 |
| 28–29 | Deployment, production architecture | 🔴 | 10, 17 | 🚧 |
| 30–32 | Projects, interviews, cheat sheets | mixed | varies | 🚧 |
| 33 | Theme vs app vs headless | 🟡 | 03 | ✅ |
| 34 | Where do I put this? | 🟡 | 03 | ✅ |

## Learning checkpoints (apply after every module)

1. **What you should know now**: list the terms and files you can name.
2. **Explain it without documentation**: say aloud how the concept flows from Admin to rendered HTML.
3. **Build it from scratch**: no copy-paste.
4. **Debug it**: break it deliberately and find the cause.
5. **Explain why Shopify works this way**: name the boundary and the reason for it.

## Chapter template (used by every chapter)

What this is · Why it matters · Mental model · Shopify concept · Developer perspective · Architecture · Example · Code · Line-by-line · Common patterns · Common mistakes · Debugging · Performance · Accessibility · Security · Production considerations · Practice task · Mini challenge · Interview questions · Further reading

## Checkpoint: after chapters 01–04

- Can you name, in order, the layers from Admin data to browser?
- Can you say which of those layers you can edit and which Shopify owns?
- Can you list the theme directories and what each is for, from memory?
- Can you explain why a JSON template contains no Liquid logic?

If any answer is no, re-read 03 before continuing.

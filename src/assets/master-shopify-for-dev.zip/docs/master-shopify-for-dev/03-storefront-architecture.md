# 03 · Storefront Architecture and How a Shopify Page Actually Works

🟢 Beginner → 🟡 Intermediate

> This is the most important chapter. Every later chapter assumes you can reproduce these diagrams from memory.

Verification markers: ✅ verified against shopify.dev on 2026-10-06 (theme architecture page) · ⚠️ confirm on shopify.dev before relying on it.

## What this is

The complete path from merchant data in Shopify Admin to pixels in the customer's browser, and onward to cart and checkout, with a clear answer to "who runs this, and where?"

## Why it matters

When something is wrong on a storefront, the first question is **which layer is wrong**: data, Liquid, HTML, CSS, JavaScript, an app, or Shopify platform logic. Without the layered model you debug by guessing.

## Mental model

```mermaid
flowchart TD
    Admin[Shopify Admin<br/>merchant edits] --> Data[(Store data<br/>products, variants, collections,<br/>customers, orders, content, metafields)]
    Data --> Theme
    subgraph Theme [Theme: you control]
      Layout[layout/theme.liquid] --> Template[templates/product.json]
      Template --> Sections[sections/*.liquid]
      Sections --> Blocks[blocks]
      Sections --> Snippets[snippets/*.liquid]
    end
    Theme --> Liquid[Liquid rendering on Shopify servers]
    Liquid --> HTML
    HTML --> Browser
    Browser --> CSS & JS
    JS --> Cart[Cart]
    Cart --> Checkout[Checkout<br/>Shopify controls]
```

## Layer-by-layer reference ✅

Component descriptions below follow Shopify's theme architecture documentation.

| Layer | What it is | Why it exists | Who controls it | Merchant-configurable? | Developer-modifiable? | File location | Data in → output |
|---|---|---|---|---|---|---|---|
| **Admin data** | Products, variants, collections, customers, orders, content | Single source of truth | Merchant (and apps via API) | Yes | Via API/Liquid read | Not a file | n/a |
| **Layout** | Base wrapper repeated on every page: `<head>`, header/footer groups | Avoid repeating chrome on every page | Developer | Via section groups | Yes | `layout/theme.liquid` (only file strictly required for upload ✅) | Global objects in → full HTML document out |
| **Template** | Decides what a page type shows | One template per resource type, with alternates | Developer; merchant chooses assignment | Partly | Yes | `templates/product.json` or `.liquid` | Route's resource in → ordered list of sections |
| **JSON template** | Wrapper listing sections and their settings; **contains no Liquid code** ✅ | Lets merchants add/reorder sections | Developer defines; merchant edits via theme editor | **Yes** | Yes | `templates/*.json` | Section order + settings → rendered sections |
| **Section group** | JSON container for reorderable sections in layout areas (header/footer) ✅ | Merchant-editable header/footer | Developer defines; merchant edits | Yes | Yes | `sections/*.json` | Same as above |
| **Section** | Reusable, customizable Liquid module with schema ✅ | The main merchant-configurable unit | Developer | Yes (via schema) | Yes | `sections/*.liquid` | Section settings + page objects in → HTML out |
| **Block** | Reusable module inside a section; can be section-local or theme-level ✅ | Merchant reorders content within a section | Developer | Yes | Yes | schema `blocks` or `blocks/*.liquid` | Block settings in → HTML out |
| **Snippet** | Reusable Liquid/HTML, **invisible to the merchant in the theme editor** ✅ | Remove duplication | Developer | No | Yes | `snippets/*.liquid` | Parameters passed by `render` in → HTML out |
| **Assets** | CSS, JS, images, fonts | Presentation and behavior | Developer | No | Yes | `assets/` | Served via `asset_url` |
| **Locales** | Translation strings | i18n and merchant-editable text | Developer; merchant edits some | Partly | Yes | `locales/*.json` | Key in → string out |
| **Config** | Theme settings schema and values | Global settings (color, type) | Developer defines; merchant sets | Yes | Yes | `config/settings_schema.json`, `settings_data.json` | Values in → `settings` object |
| **Browser JS** | Client behavior | Interactivity | Developer (and apps) | No | Yes | `assets/*.js` | DOM + fetch → UI updates |
| **Cart** | Shopify-held cart state | Shared by theme, apps, checkout | Shopify | No | Via Cart API | n/a | Variant IDs in → cart JSON out |
| **Checkout** | Payment and order placement | Security, PCI, conversion | **Shopify** | Limited (branding, extensions) | **Only through supported extension mechanisms** | n/a | Cart in → order out |

## Where each layer lives (visual)

```text
theme/
├── layout/          theme.liquid
├── templates/       product.json, collection.json, index.json, cart.json ...
├── sections/        hero.liquid, header-group.json, footer-group.json ...
├── blocks/          theme-level blocks
├── snippets/        price.liquid, product-card.liquid ...
├── assets/          base.css, product.js ...
├── config/          settings_schema.json, settings_data.json
└── locales/         en.default.json, en.default.schema.json ...
```

## How a Shopify page actually works

Scenario: a customer visits `https://example.com/products/example-product`.

```mermaid
sequenceDiagram
    participant B as Browser
    participant S as Shopify platform
    participant T as Theme (templates/sections)
    participant L as Liquid engine
    B->>S: GET /products/example-product
    S->>S: Resolve route -> resource type "product", find product by handle
    S->>T: Pick template (product.json or assigned alternate)
    T->>S: Ordered sections + settings from JSON
    S->>L: Render layout + sections with objects (product, shop, settings, cart...)
    L->>B: HTML response
    B->>S: Request CSS/JS/images (assets from CDN)
    B->>B: Parse HTML, apply CSS, run JS
    B->>S: fetch /cart/add.js (user clicks Add to cart)
    S->>B: Cart JSON
    B->>S: Navigate to /checkout
```

### Step by step

1. **Request reaches Shopify.** There is no server of yours in the path for a theme storefront.
2. **Shopify determines the route and resource.** `/products/<handle>` maps to a product. `/collections/<handle>`, `/pages/<handle>`, `/cart`, `/search` map to their types. ⚠️ Alternate URLs such as `/collections/x/products/y` also exist; canonical URL handling is covered in chapter 23.
3. **Shopify selects the template.** It uses the template assigned to that product (default or alternate). Every page type needs a matching template to render ✅.
4. **JSON template is read.** It is a wrapper only: an ordered list of sections with settings and blocks ✅.
5. **Sections are resolved.** Each section entry names a file in `sections/`. Layout section groups (header/footer) resolve too.
6. **Section settings load.** Merchant-edited values from the template JSON, validated against each section's `{% schema %}`.
7. **Liquid receives Shopify objects.** `product`, `collection`, `cart`, `shop`, `settings`, `request`, `localization`, and more, depending on context.
8. **Liquid renders HTML on Shopify's servers.** All `{% %}` and `{{ }}` are evaluated here. **The browser never sees Liquid.**
9. **Assets load.** `<link>` and `<script>` tags request files from `assets/` via CDN URLs (`asset_url`).
10. **JavaScript runs** in the browser: variant selectors, cart drawer, predictive search.
11. **The browser renders** HTML + CSS and applies JS behavior.
12. **Customer interactions trigger frontend behavior.** JS reacts to clicks and calls Shopify endpoints.
13. **Cart state changes** in Shopify's cart via the Ajax Cart API ⚠️ (`/cart/add.js`, `/cart/change.js`, `/cart/update.js`, `/cart.js`) or via forms.
14. **Checkout transition.** The browser navigates to checkout, which Shopify renders. Theme layout and sections do not render it.

## Server-side rendering vs client JavaScript vs platform logic

| Concern | Liquid (server render) | Browser JS | Shopify platform |
|---|---|---|---|
| Output product title, price | ✅ yes | no (already in HTML) | supplies data |
| Choose which variant is selected on load | ✅ `selected_or_first_available_variant` | may update later | resolves `?variant=` |
| Respond to a click on a color swatch | no | ✅ | n/a |
| Update the cart without reload | no | ✅ calls Cart API | ✅ holds cart |
| Final price after discounts | no (can only estimate) | no (display only) | ✅ computed in cart/checkout |
| Enforce inventory limits | no | no (UX only) | ✅ |
| Process payment | no | no | ✅ checkout |
| Fetch private customer data from an ERP | **never** | **never** | needs app/server |

Key rule: **Liquid runs once per request on Shopify's servers. JS runs after.** If data must change without reloading, you need JS plus an endpoint (Cart API, Section Rendering API ⚠️, Storefront API).

## Code: seeing the layers in one request

`templates/product.json` (wrapper only):

```json
{
  "sections": {
    "main": {
      "type": "main-product",
      "settings": { "show_vendor": true }
    },
    "recommendations": {
      "type": "product-recommendations",
      "settings": {}
    }
  },
  "order": ["main", "recommendations"]
}
```

`sections/main-product.liquid` (renders data, exposes settings):

```liquid
{%- liquid
  assign current_variant = product.selected_or_first_available_variant
-%}

<section class="main-product" data-section-id="{{ section.id }}">
  <h1>{{ product.title | escape }}</h1>

  {%- if section.settings.show_vendor and product.vendor != blank -%}
    <p class="main-product__vendor">{{ product.vendor | escape }}</p>
  {%- endif -%}

  <p class="main-product__price">{{ current_variant.price | money }}</p>

  {%- form 'product', product -%}
    <input type="hidden" name="id" value="{{ current_variant.id }}">
    <button type="submit" {% unless current_variant.available %}disabled{% endunless %}>
      {{ 'products.product.add_to_cart' | t }}
    </button>
  {%- endform -%}
</section>

{% schema %}
{
  "name": "Main product",
  "settings": [
    { "type": "checkbox", "id": "show_vendor", "label": "Show vendor", "default": true }
  ]
}
{% endschema %}
```

### Line by line

- `templates/product.json`: lists sections by `type` (file name in `sections/`). No Liquid logic lives here ✅.
- `assign current_variant`: Shopify has already loaded `product`; Liquid only reads it.
- `| escape`: output encoding for text that may contain special characters (see security chapter).
- `section.settings.show_vendor`: the value the merchant set in the theme editor, validated by the schema below.
- `{% form 'product', product %}`: generates a form that posts to the cart. Shopify's docs note that themes need a `form` tag of type `product` to let customers add to cart ✅.
- `name="id"` with the **variant** ID: not the product ID.
- `{% schema %}`: tells the theme editor which settings exist. Without it, the merchant gets nothing configurable.

## Common patterns

- Section owns layout and settings; snippets own small reusable fragments.
- Pass data to snippets with explicit parameters (`render`), not by relying on global variables.
- Progressive enhancement: the `form` works without JS; JS upgrades it to AJAX.

## Common mistakes

- Expecting Liquid to run in the browser or to re-run after a click.
- Treating `product.id` as the cart ID.
- Putting merchant-configurable content directly in a snippet (merchant can't edit it).
- Editing JSON templates by hand while the merchant is also editing in the theme editor (conflicts; see chapter 10).

## Debugging

| Symptom | Investigate |
|---|---|
| Page renders blank section | Is the section listed in the template's `order`? Does the file name match `type`? |
| Setting changes do nothing | Does `section.settings.<id>` match the schema `id` exactly? |
| Price shown differs from checkout | Discounts and markets are applied after render. Check cart/checkout, not the Liquid output. |
| JS cannot find an element | HTML is server-rendered; check it in "View source", then DOM after JS. |

## Performance

- Each section adds server render time and DOM weight. Sections are not free.
- Assets are CDN-served; keep JS/CSS scoped. Detailed budget in chapter 22.

## Accessibility

- Layout owns landmarks (`header`, `main`, `footer`). Sections own headings. Keep heading hierarchy consistent across sections.

## Security

- Escape output you did not author. Never put secrets in Liquid output or theme JS.

## Production considerations

- Know which layer owns a defect before editing. Fixing a data problem in CSS is a classic time sink.

## Practice task

Open any Dawn-based store. In View Source, find the `<section>` for the main product. Locate the matching file in `sections/`, and the template JSON that includes it.

## Mini challenge

On paper, label every box in the first diagram with: runs on Shopify / runs in browser / merchant edits it / developer edits it.

## Interview questions

1. What happens between a customer typing a product URL and seeing HTML?
2. Why can't Liquid react to a click?
3. What is the difference between a JSON template and a Liquid template? ✅ JSON templates only wrap sections; Liquid templates contain code.
4. Why is checkout not part of the theme?

## Checkpoint

- Can you reproduce the sequence diagram without looking?
- Can you say, for any bug description, which layer to inspect first?
- Can you explain why the cart is shared between theme, apps, and checkout?

## Further reading

- Theme architecture: https://shopify.dev/docs/storefronts/themes/architecture

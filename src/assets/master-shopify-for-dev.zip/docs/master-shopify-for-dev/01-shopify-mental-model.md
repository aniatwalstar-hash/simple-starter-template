# 01 · The Shopify Mental Model

🟢 Beginner

## What this is

A way of thinking about Shopify as a **platform with fixed boundaries** instead of a blank server you control.

## Why it matters

Most wasted Shopify time comes from carrying assumptions from other stacks. Shopify decides what runs where. Your job is to find the correct extension point, not to bend the platform.

## Mental model

Shopify is four systems stacked together:

```mermaid
flowchart TB
    subgraph Shopify-owned
      A[Commerce engine: products, orders, inventory, discounts, payments]
      B[Checkout]
      C[Admin]
    end
    subgraph You-extend
      D[Theme: Liquid + HTML/CSS/JS]
      E[Apps + extensions + Functions]
      F[Headless frontend]
    end
    A --> D
    A --> E
    A --> F
    D --> B
    E --> B
    F --> B
```

Rules of thumb:

- **Data lives in Shopify.** You read and write it through Liquid, Ajax Cart API, Storefront API, or Admin API.
- **Pages are rendered by Shopify** (for themes). You provide templates; Shopify provides the data and the server.
- **Checkout is Shopify's.** You extend it only through supported extension mechanisms. See [19 Checkout extensibility](00-roadmap.md).
- **Private credentials never go to the browser.** Anything needing secrets runs server-side (an app or your own backend).

## Shopify concept: the "source of truth"

**Source of truth**: the one place a piece of data authoritatively lives.

Plain English: if two places disagree, the source of truth wins.
Technical: for a product price, the source of truth is Shopify's product/variant record, not the number printed in your HTML.
Example: a theme that hardcodes "$49" in a section will drift from the real price. Always read price from the variant object.

## Developer perspective: if you come from WordPress/WooCommerce

| WordPress/Woo habit | Shopify reality |
|---|---|
| Edit PHP template files directly on a server | Themes are Liquid files uploaded to Shopify. No server access. |
| Install plugins that run PHP in your process | Apps run on *their own* servers and integrate via APIs/extensions. They do not execute inside your theme's runtime. |
| `functions.php` can do anything | There is no equivalent. Server-side logic belongs in an app or Shopify Functions. |
| Query the database with `WP_Query` | You cannot query the database. You use Liquid objects, or GraphQL APIs. |
| Hooks and filters everywhere | Extension points are explicit: sections/blocks, app blocks/embeds, checkout targets, Functions. |
| Edit checkout template | Checkout is not a theme file you edit. See chapter 19. |
| Custom post types / ACF | Metafields and metaobjects. See chapter 12. |

Where the analogy breaks: WordPress lets you reach anywhere. Shopify gives you well-defined doors. Learning the doors is the skill.

## Architecture (the three developer tracks)

```mermaid
flowchart LR
    T[Theme track<br/>Liquid, sections, JS] --> S[(Shopify)]
    A[App track<br/>server, webhooks, extensions] --> S
    H[Headless track<br/>custom frontend, Storefront API] --> S
```

Each track has a different answer to "where does my code run?":

- Theme: rendered by Shopify (Liquid) and executed in the browser (JS).
- App: your server, plus Shopify-hosted extension surfaces.
- Headless: your frontend host, calling Storefront API.

## Example

Requirement: "Show a badge when a product is on sale."

- Wrong: hardcode a badge per product in HTML.
- Right: compare `compare_at_price` with `price` in Liquid, using the variant's data, so the badge follows merchant edits automatically.

```liquid
{%- liquid
  assign current_variant = product.selected_or_first_available_variant
  assign on_sale = false
  if current_variant.compare_at_price > current_variant.price
    assign on_sale = true
  endif
-%}
{% if on_sale %}
  <span class="badge">{{ 'products.product.on_sale' | t }}</span>
{% endif %}
```

Line by line:

1. `assign current_variant = ...`: picks the variant being shown. Product is the container; **variant is what has a price**.
2. `compare_at_price > price`: both are integers in the shop's currency subunits. Comparison is safe in Liquid.
3. `'products.product.on_sale' | t`: reads translated text from `locales/*.json`. No hardcoded English.

## Common mistakes

- Treating Shopify like WordPress (see table above).
- Putting business rules in Liquid that belong in an app or a Function.
- Hardcoding merchant data (prices, store name, URLs).
- Editing the live theme directly.

## Production considerations

- Know which theme is published before you edit anything.
- Treat theme files as code: Git, review, staging. See [10 CLI + Git](10-shopify-cli-git.md).

## Practice task

Draw, from memory, the diagram at the top of this page and mark which boxes you can edit.

## Mini challenge

Your client says "calculate a custom wholesale price in the theme using a secret ERP key." Which track, and why can't it live in Liquid? (Answer: app/server track. Liquid and browser JS are not places for secrets.)

## Interview questions

1. Why can't a theme query the database directly?
2. Where would you store an API secret and why?
3. Name three differences between WordPress plugins and Shopify apps.

## Checkpoint

- Can you explain "source of truth" with a Shopify example?
- Can you name the three developer tracks and what each owns?
